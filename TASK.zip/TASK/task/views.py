# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.shortcuts import *
from .models import *
from django.http import *
def home(request):
	template = loader.get_template('navbar.html')
    	context = {}
	return HttpResponse(template.render(context, request))
def register(request):
        if request.method == 'POST':
		user=Candidates()
		user.username=request.POST.get('username')
		user.email=request.POST.get('email')
		user.password=request.POST.get('password')
		user.save()
		template = loader.get_template('login.html')
    		context = {'success':1}
		return HttpResponse(template.render(context, request))
        else:
		template = loader.get_template('register.html')
	    	context = {}
		return HttpResponse(template.render(context, request))
def login(request):
        if request.method == 'POST':
		if Candidates.objects.get(username=request.POST.get('username')) and Candidates.objects.get(username=request.POST.get('username')).password==request.POST.get('password'):
			request.session['username']=request.POST.get('username')
     			return redirect(reverse('task:view_profile'))
			#template = loader.get_template('view_profile.html')	
    			#context = {'success':1,}
			#return HttpResponse(template.render(context, request))		
		else:
			template = loader.get_template('login.html')
    			context = {'success':0}
			return HttpResponse(template.render(context, request))
	else:
		template = loader.get_template('login.html')
    		context = {'success':2}
		return HttpResponse(template.render(context, request))	
def view_profile(request):
        user=Candidates.objects.get(username=request.session['username'])
	template = loader.get_template('view_profile.html')	
    	context = {'success':1,'user':user}
	return HttpResponse(template.render(context, request))
def edit(request):
        if request.method == 'POST':
		user=Candidates.objects.get(username=request.session['username'])
                user.username=request.POST.get('username')
		user.email=request.POST.get('email')
		user.password=request.POST.get('password')
                user.save()
                request.session['username']=request.POST.get('username')
		template = loader.get_template('edit.html')	
	    	context = {'edit':1}
		return HttpResponse(template.render(context, request))
	else:
		template = loader.get_template('edit.html')
    		context = {}
		return HttpResponse(template.render(context, request))	
	

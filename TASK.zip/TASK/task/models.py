# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Candidates(models.Model):
	registration_id=models.AutoField(primary_key=True)
	username=models.CharField(max_length=30,unique=True)
	email=models.EmailField(max_length=254,unique=True)
        password=models.CharField(max_length=30)
